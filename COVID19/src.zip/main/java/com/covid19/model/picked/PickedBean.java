package com.covid19.model.picked;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class PickedBean {

	private String specialJob;
	private String ageUpDown;
	private String pragnent;
}
