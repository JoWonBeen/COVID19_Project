package com.covid19.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RootAppContext {

}
